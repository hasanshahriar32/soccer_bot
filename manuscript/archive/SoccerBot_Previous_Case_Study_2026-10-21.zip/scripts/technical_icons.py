"""Original geometric robotics symbols, drawn in code in a 64 × 64 view box.

These are schematic component glyphs, not measured robot geometry or vendor
artwork. Adapted from the native SVG approach used in our earlier manuscript.
"""
from html import escape

INK='#263645'
SYMBOLS={
'camera': '''<path d="M10 18h10l5-7h17l5 7h7v32H10Z" fill="#dce7ee"/>
 <path d="M47 18h7v32h-7Z" fill="#becfdd"/><circle cx="32" cy="34" r="12" fill="#f8fbfc"/>
 <circle cx="32" cy="34" r="7" fill="#9bbbcf"/><circle cx="32" cy="34" r="3" fill="#008b91" stroke="none"/>
 <path d="M15 24h6M24 55h16M32 50v5"/>''',
'lidar': '''<ellipse cx="32" cy="45" rx="23" ry="9" fill="#becfdd"/>
 <path d="M9 28v17c0 12 46 12 46 0V28Z" fill="#dce7ee"/>
 <ellipse cx="32" cy="28" rx="23" ry="9" fill="#f8fbfc"/>
 <path d="M15 34v8c9 6 25 6 34 0v-8" fill="#356d93"/>
 <path d="M32 15V5M19 17 12 9M45 17l7-8" stroke="#008b91"/>
 <circle cx="32" cy="28" r="4" fill="#008b91" stroke="none"/>''',
'sbc': '''<path d="M8 13 51 8l7 42-43 6Z" fill="#dce7ee"/>
 <path d="m51 8 4 2 7 42-4-2Z" fill="#becfdd"/>
 <path d="M22 25h20v18H22Z" fill="#356d93"/>
 <path d="M25 21v4M31 21v4M37 21v4M25 43v4M31 43v4M37 43v4M18 29h4M18 37h4M42 29h4M42 37h4"/>
 <path d="M8 17h9v11H8ZM12 38h9v11h-9ZM28 8h18v7H28Z" fill="#f8fbfc"/>
 <circle cx="48" cy="45" r="2" fill="#008b91" stroke="none"/>''',
'laptop': '''<path d="M8 8h48v35H8Z" fill="#becfdd"/>
 <path d="M12 12h40v27H12Z" fill="#f8fbfc"/>
 <path d="M8 43h48l7 11H1Z" fill="#dce7ee"/>
 <path d="M9 48h46M27 51h10M22 20l-6 6 6 6M42 20l6 6-6 6M35 17l-6 18" fill="none" stroke="#008b91"/>''',
'bridge': '''<path d="M15 9h34v46H15Z" fill="#dce7ee"/>
 <path d="M20 14h24v11H20Z" fill="#f8fbfc"/>
 <path d="M6 34h19m-5-5 5 5-5 5M58 43H39m5-5-5 5 5 5" stroke="#008b91" fill="none"/>
 <path d="M22 48h11M22 18h12" stroke="#356d93"/>''',
'controller': '''<path d="M16 15h33v35H16Z" fill="#dce7ee"/>
 <path d="M23 22h19v21H23Z" fill="#356d93"/>
 <path d="M22 7v8M32 7v8M42 7v8M22 50v8M32 50v8M42 50v8M8 22h8M8 32h8M8 42h8M49 22h8M49 32h8M49 42h8"/>
 <path d="m28 32 4 4 7-9" fill="none" stroke="#f8fbfc" stroke-width="2.2"/>''',
'fusion': '''<path d="M11 8h42v47H11Z" fill="#f8fbfc"/>
 <circle cx="21" cy="21" r="5" fill="#9bbbcf"/><circle cx="43" cy="21" r="5" fill="#008b91"/>
 <path d="M21 26v8h11M43 26v8H32v9" fill="none"/>
 <circle cx="32" cy="47" r="5" fill="#dce7ee"/>''',
'mcu': '''<path d="M8 11h48v41H8Z" fill="#dce7ee"/>
 <path d="M23 22h21v18H23Z" fill="#356d93"/>
 <path d="M13 6h36v5H13ZM13 52h36v5H13ZM4 22h10v13H4Z" fill="#becfdd"/>
 <path d="M29 18v4M36 18v4M29 40v4M36 40v4"/>
 <circle cx="49" cy="43" r="2" fill="#008b91" stroke="none"/>''',
'driver': '''<path d="M7 17h50v35H7Z" fill="#dce7ee"/>
 <path d="M18 12h27v25H18Z" fill="#becfdd"/>
 <path d="M23 12v25M29 12v25M35 12v25M41 12v25"/>
 <path d="M10 43h13v9H10ZM41 43h13v9H41Z" fill="#9bbbcf"/>
 <circle cx="15" cy="48" r="1.3"/><circle cx="20" cy="48" r="1.3"/>
 <circle cx="45" cy="48" r="1.3"/><circle cx="50" cy="48" r="1.3"/>''',
'drive': '''<path d="M17 14h30v38H17Z" fill="#dce7ee"/>
 <path d="M6 17h11v32H6ZM47 17h11v32H47Z" fill="#becfdd"/>
 <path d="M6 24h11M6 32h11M6 40h11M47 24h11M47 32h11M47 40h11"/>
 <path d="M32 43V20m-7 7 7-7 7 7" stroke="#008b91" fill="none"/>
 <circle cx="32" cy="49" r="2.6" fill="#f8fbfc"/>''',
'gate': '''<path d="M32 5 54 14v19c0 12-10 20-22 27C20 53 10 45 10 33V14Z" fill="#e6f3f1"/>
 <path d="m20 32 8 8 17-19" stroke="#008b91" stroke-width="3.4" fill="none"/>''',
'capture': '''<path d="M12 7h29l11 11v40H12Z" fill="#f8fbfc"/>
 <path d="M41 7v12h11M20 29h23M20 36h23M20 43h23M20 50h15" fill="none" stroke="#356d93"/>
 <path d="M18 13h12v8H18Z" fill="#dce7ee"/>''',
'clock': '''<circle cx="32" cy="33" r="23" fill="#f8fbfc"/>
 <path d="M32 16v17l11 7M25 4h14M32 4v6" fill="none"/>
 <path d="m16 14-5-5M48 14l5-5" stroke="#008b91"/>''',
}

def svg_symbols():
    return '<defs>'+''.join(f'<symbol id="{name}" viewBox="0 0 64 64"><g stroke="{INK}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{body}</g></symbol>' for name,body in SYMBOLS.items())+'</defs>'

def icon_use(name,x,y,width=64):
    if name not in SYMBOLS:
        raise ValueError(name)
    return f'<use href="#{escape(name)}" x="{x}" y="{y}" width="{width}" height="{width}"/>'
