#!/usr/bin/env python3
"""Generate source-grounded technical diagrams and plots from frozen replay data.

Only manuscript outputs are written. No ROS nodes, sockets or hardware are used.
The CSV/JSON inputs and original controller remain unchanged.
"""
import csv
import hashlib
import json
from pathlib import Path
import platform
import subprocess

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np

from render_technical_figures import render as render_diagrams

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'figures'
POLICIES=('source','freshness_only','full_supervisor')
LABELS={'source':'B · source','freshness_only':'F · age only','full_supervisor':'V · age + validity'}
COLORS={'source':'#263645','freshness_only':'#a67529','full_supervisor':'#008b91'}
MUTED='#647582'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.5,'axes.labelsize':7.5,
 'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'ps.fonttype':42,
 'svg.fonttype':'none','svg.hashsalt':'soccerbot-replay-figures-v1',
 'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b1bec7',
 'axes.labelcolor':'#263645','text.color':'#263645','xtick.color':MUTED,'ytick.color':MUTED})


def save(fig,name):
    for suffix in ('pdf','svg','png'):
        meta={'Creator':'SoccerBot reproducible figure renderer'} if suffix=='pdf' else {}
        if suffix=='pdf': meta.update({'Author':'','CreationDate':None,'ModDate':None})
        if suffix=='svg': meta={'Date':None,'Creator':'SoccerBot reproducible figure renderer'}
        fig.savefig(OUT/f'{name}.{suffix}',dpi=300,facecolor='white',metadata=meta)
    plt.close(fig)


def spans(times,dt):
    intervals=[]
    for value in times:
        if intervals and abs(value-intervals[-1][1])<1e-8:
            intervals[-1][1]=value+dt
        else: intervals.append([value,value+dt])
    return intervals


def fault_trace(rows,data):
    hz=data['settings']['control_hz']; dt=1/hz
    fig,axes=plt.subplots(2,1,figsize=(3.45,3.00),sharex=True)
    fig.subplots_adjust(left=.20,right=.98,bottom=.17,top=.80,hspace=.60)
    records={}
    for panel,(ax,scenario,title,flag,shade) in enumerate(zip(axes,
        ['scan_dropout','all_invalid_scan'],['Scan stream interruption','Fresh, all-invalid scans'],
        ['unknown_or_stale_scan','invalid_scan'],['#f5ead6','#fbe9e5'])):
        selected={p:[r for r in rows if r['scenario']==scenario and r['policy']==p] for p in POLICIES}
        reference=selected['full_supervisor']
        times=[float(r['time_s']) for r in reference]
        constrained=[float(r['time_s']) for r in reference if flag in r['constraints'].split('|')]
        intervals=spans(constrained,dt)
        for start,end in intervals: ax.axvspan(start,end,color=shade,zorder=0)
        for policy in POLICIES:
            sample=selected[policy]
            # Wider source/full lines make coincident age-only dashes visible.
            lw=2.7 if policy in ('source','full_supervisor') else 1.25
            values=[float(r['output_linear']) for r in sample]
            ax.step(times+[times[-1]+dt],values+[values[-1]],where='post',color=COLORS[policy],
                lw=lw,ls='--' if policy=='freshness_only' else '-',zorder=6 if policy=='freshness_only' else 3,
                label=LABELS[policy])
        receipts=[r for r in reference if r['scan_input']!='none']
        valid=[float(r['time_s']) for r in receipts if r['scan_valid']=='1']
        invalid=[float(r['time_s']) for r in receipts if r['scan_valid']=='0']
        ax.plot(valid,[.345]*len(valid),'|',color='#356d93',ms=4,mew=.8,clip_on=False)
        ax.plot(invalid,[.345]*len(invalid),'|',color='#a84b45',ms=4,mew=.8,clip_on=False)
        ax.set_title(f'({chr(97+panel)})  {title}',loc='left',fontsize=8.3,fontweight='bold',pad=11)
        ax.set(xlim=(0,4),ylim=(-.035,.36),yticks=[0,.28],ylabel='Requested v\n(m/s)')
        ax.grid(axis='y',color='#dfe6eb',lw=.6,zorder=0)
        ax.tick_params(length=2.5)
        label='F = V: request zero' if panel==0 else 'B = F: continue forward'
        y=.08 if panel==0 else .20
        ax.text(2,y,label,ha='center',fontsize=7,color='#263645')
        if panel==0:
            first=intervals[0][0]
            last=max(float(r['time_s']) for r in receipts if float(r['time_s'])<first)
            ax.axvline(last,color=MUTED,lw=.7,ls=':')
            ax.annotate(f'Age expires\n{first:.2f} s',xy=(first,.025),xytext=(.14,.10),fontsize=6.5,
                        arrowprops={'arrowstyle':'-','color':MUTED,'lw':.6})
        records[scenario]={'constraint':flag,'shaded_intervals_s':intervals,
                          'receipt_times_s':{'valid':valid,'invalid':invalid},
                          'policy_linear_commands':{p:[float(r['output_linear']) for r in selected[p]] for p in POLICIES},
                          'time_s':times}
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,ncol=3,loc='upper center',bbox_to_anchor=(.54,.995),
               frameon=False,fontsize=6.8,handlelength=1.9,columnspacing=.8)
    axes[-1].set_xlabel('Constructed time (s)')
    save(fig,'fault_trace')
    return records


def timeout_tradeoff(data):
    rows=data['timeout_sweep']
    x=[float(r['scan_ttl_s']) for r in rows]
    held=[r['slow_scan_forward_held_ticks'] for r in rows]
    persistence=[r['dropout_forward_duration_after_last_scan_s'] for r in rows]
    fig,axes=plt.subplots(1,2,figsize=(3.45,2.18))
    fig.subplots_adjust(left=.14,right=.985,bottom=.23,top=.77,wspace=.52)
    fig.suptitle('Scan timeout: persistence versus holding',x=.51,y=.985,fontsize=8.3,fontweight='bold')
    for ax in axes:
        ax.set_xticks(x,[f'{v:.2f}' for v in x]); ax.set_xlabel('Scan timeout (s)'); ax.grid(axis='y',color='#e1e7eb',lw=.6)
        ax.tick_params(length=2.5)
    axes[0].plot(x,persistence,'o-',color='#356d93',lw=1.4,ms=4)
    axes[0].set(ylabel='Persistence (s)',ylim=(-.04,.6),yticks=[0,.25,.5])
    axes[0].set_title('(a) Scan interruption',loc='left',fontsize=7.3,pad=8)
    axes[1].plot(x,held,'s-',color='#008b91',lw=1.4,ms=4)
    axes[1].set(ylabel=f"Held ticks / {data['settings']['ticks_per_scenario']}",ylim=(-7,77),yticks=[0,30,60])
    axes[1].set_title('(b) Clear 2.5 Hz scans',loc='left',fontsize=7.3,pad=8)
    for i in range(len(rows)):
        axes[0].annotate(f'{persistence[i]:.2f}',(x[i],persistence[i]),xytext=(0,7),textcoords='offset points',ha='center',fontsize=7)
        axes[1].annotate(str(held[i]),(x[i],held[i]),xytext=(0,7),textcoords='offset points',ha='center',fontsize=7)
    save(fig,'timeout_tradeoff')
    return rows


def scenario_matrix(data):
    order=[r for r in data['per_scenario'] if r['policy']=='source']
    labels=[r['label'] for r in order]
    scenarios=[r['scenario'] for r in order]
    blocks=[]
    for metric in ('constrained_motion_ticks','clear_forward_held_ticks'):
        blocks.append(np.array([[next(r[metric] for r in data['per_scenario'] if r['scenario']==s and r['policy']==p)
                      for p in POLICIES] for s in scenarios]))
    fig,axes=plt.subplots(1,2,figsize=(7.1,3.45),sharey=True)
    fig.subplots_adjust(left=.30,right=.965,bottom=.13,top=.82,wspace=.40)
    fig.suptitle('All constructed scenarios: conformance and availability',x=.53,y=.98,fontsize=10,fontweight='bold')
    vmax=max(int(b.max()) for b in blocks)
    for i,(ax,values) in enumerate(zip(axes,blocks)):
        cmap=plt.get_cmap('Blues' if i==0 else 'YlOrBr')
        ax.set(xlim=(-.5,2.5),ylim=(len(labels)-.5,-.5))
        # Native vector cells keep the PDF/SVG free of embedded raster tiles.
        for row in range(values.shape[0]):
            for col in range(3):
                ax.add_patch(Rectangle((col-.5,row-.5),1,1,
                    facecolor=cmap(float(values[row,col])/max(vmax,1)),edgecolor='white',linewidth=.6))
        ax.set_xticks(range(3),['B: source','F: age','V: full'],fontsize=7.5)
        ax.set_yticks(range(len(labels)),labels,fontsize=7.8)
        ax.tick_params(length=0,pad=5)
        ax.set_title('Constrained motion T (ticks)' if i==0 else 'Held clear-scene forward H (ticks)',fontsize=8.5,pad=10)
        for row in range(values.shape[0]):
            for col in range(3):
                value=int(values[row,col]); ax.text(col,row,str(value),ha='center',va='center',fontsize=8,
                    color='white' if value>vmax*.60 else '#263645',fontweight='bold' if value else 'normal')
        for edge in ax.spines.values(): edge.set_visible(False)
        ax.set_xticks(np.arange(-.5,3,1),minor=True); ax.set_yticks(np.arange(-.5,len(labels),1),minor=True)
        ax.grid(which='minor',color='white',lw=1.2); ax.tick_params(which='minor',length=0)
    save(fig,'scenario_matrix')
    return {'scenarios':scenarios,'labels':labels,'policies':list(POLICIES),
            'constrained_motion_ticks':blocks[0].tolist(),'clear_forward_held_ticks':blocks[1].tolist()}


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    data=json.loads((BASE/'data/replay_results.json').read_text())
    with (BASE/'data/replay_trace.csv').open(newline='') as stream: rows=list(csv.DictReader(stream))
    records={'semantics':'Constructed command-level evidence; no physical motion or empirical failure-rate measurements.',
             'settings':data['settings'],'architecture':render_diagrams(data)}
    records['fault_trace']=fault_trace(rows,data)
    records['timeout_tradeoff']=timeout_tradeoff(data)
    records['scenario_matrix']=scenario_matrix(data)
    (BASE/'data/figure_data.json').write_text(json.dumps(records,indent=2)+'\n')
    stems={'architecture':True,'fault_trace':True,'timeout_tradeoff':True,'contract_gate':False,'scenario_matrix':False}
    inputs=[BASE/'data'/name for name in ('replay_results.json','replay_trace.csv','replay_summary.csv','timeout_sweep.csv')]
    runtime=[BASE.parent/p for p in ['src/soccer_vision/soccer_vision/ball_tracker_node.py',
       'src/soccer_vision/soccer_vision/camera_hub_node.py','src/soccer_navigation/soccer_navigation/autonomous_ball_chaser_node.py',
       'motor_control/motor_server.py','motor_control/soccer_bot_motor_driver.ino']]
    scripts=[Path(__file__).resolve(),BASE/'scripts/render_technical_figures.py',BASE/'scripts/technical_icons.py',BASE/'scripts/export_drawio.py']
    exports=[OUT/f'{stem}.{suffix}' for stem in stems for suffix in ('pdf','svg','png')]
    exports += [OUT/'architecture.drawio',OUT/'contract_gate.drawio',BASE/'data/figure_data.json']
    manifest={'generator':'Original SVG technical glyphs + librsvg; Matplotlib plots from frozen replay',
      'python_version':platform.python_version(),'matplotlib_version':matplotlib.__version__,'numpy_version':np.__version__,
      'librsvg_version':subprocess.check_output(['rsvg-convert','--version'],text=True).strip(),
      'figures':{name:{'in_paper':paper} for name,paper in stems.items()},
      'inputs_sha256':{str(p.relative_to(BASE)):sha(p) for p in inputs},
      'source_evidence_sha256':{str(p.relative_to(BASE.parent)):sha(p) for p in runtime},
      'scripts_sha256':{str(p.relative_to(BASE)):sha(p) for p in scripts},
      'outputs_sha256':{str(p.relative_to(BASE)):sha(p) for p in exports}}
    (BASE/'data/figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Generated five PDF/SVG/PNG figure sets and two editable draw.io diagrams.')
    print('Main paper: architecture, paired fault traces and timeout tradeoff.')
    print('Source bindings and plotted values: manuscript/data/figure_manifest.json and figure_data.json')

if __name__=='__main__': main()
