# SoccerBot research figures

These figures use the same code-first vector approach as the earlier manuscript, adapted to this robot and its experiments. Original component glyphs depict the camera, LiDAR, Raspberry Pi, laptop, controller, Arduino, driver and drive wheels. Every quantitative mark comes from the saved constructed replay; no image-generation service, stock artwork, hardware trial or live robot connection is used.

| Figure | Exports | Purpose and evidence |
|---|---|---|
| 1. Distributed architecture | [PDF](architecture.pdf) · [SVG](architecture.svg) · [PNG](architecture.png) · [draw.io](architecture.drawio) | Audited sensor, ROS and actuator paths; separate offline extraction/supervision boundary. Component placement and dimensions are schematic. |
| 2. Paired fault traces | [PDF](fault_trace.pdf) · [SVG](fault_trace.svg) · [PNG](fault_trace.png) | Every saved command from the scan-interruption and all-invalid-scan traces. Receipt rugs and shaded constraints are derived from the per-tick CSV. |
| 3. Timeout tradeoff | [PDF](timeout_tradeoff.pdf) · [SVG](timeout_tradeoff.svg) · [PNG](timeout_tradeoff.png) | Three saved timeout settings, sampled forward-command persistence and suppressed clear-scene forward ticks. |
| Optional contract illustration | [PDF](contract_gate.pdf) · [SVG](contract_gate.svg) · [PNG](contract_gate.png) · [draw.io](contract_gate.drawio) | Illustrative age, range and target-contract logic; read the paper's equations for the complete predicate. |
| Optional scenario matrix | [PDF](scenario_matrix.pdf) · [SVG](scenario_matrix.svg) · [PNG](scenario_matrix.png) | All 12 scenarios and all three policies: constrained-motion counts T and held clear-scene forward counts H. Exact values are shown in each cell. |

## Reproduce and edit

From the repository root:

```bash
python3 -m pip install -r manuscript/requirements-figures.txt
python3 manuscript/scripts/build_figures.py
python3 manuscript/experiments/replay_supervisor.py --check-only
bash manuscript/compile.sh
python3 manuscript/scripts/check_submission.py
python3 manuscript/scripts/package_sources.py
```

Diagram regeneration also needs `rsvg-convert` (librsvg) and Noto Sans. Both are available in the verified environment. No game engine or icon-font package is required. Ordinary LaTeX compilation uses the committed PDFs and does not need Python or librsvg.

[render_technical_figures.py](../scripts/render_technical_figures.py) positions the original robotics symbols in [technical_icons.py](../scripts/technical_icons.py), labels and orthogonal connectors. librsvg exports vector PDF 1.5 and 300-dpi previews. [build_figures.py](../scripts/build_figures.py) generates the quantitative plots with Matplotlib. Fixed export metadata and SVG identifier seeds support byte-identical rerendering in the recorded environment.

[export_drawio.py](../scripts/export_drawio.py) creates uncompressed editable diagrams: native text, rectangles and connectors, with independently movable SVG glyphs. Open a `.drawio` file in diagrams.net or its desktop editor. The publication SVG/PDF remains the rendering authority; manual editor changes do not update the Python source automatically. XML structure is checked, but interactive draw.io rendering has not been inspected, so browser font placement can need adjustment.

The Overleaf ZIP includes the PDF, SVG and draw.io assets. Plotting code, raw replay data and source fingerprints remain in this local author-side research project; they are excluded from the anonymous typesetting bundle.

## Source map and interpretation

- Camera/image interfaces: `src/soccer_vision/soccer_vision/camera_hub_node.py`.
- Tracker, neural detections, `/image_raw`, `/scan` and metric `/ball_position`: `src/soccer_vision/soccer_vision/ball_tracker_node.py`.
- Selected metric chaser, 20-Hz nominal loop, direct TCP motor path and `/cmd_vel`: `src/soccer_navigation/soccer_navigation/autonomous_ball_chaser_node.py`.
- Motor gateway and Arduino sketch: `motor_control/motor_server.py`, `motor_control/soccer_bot_motor_driver.ino`.
- Constructed replay and full supervisor: [replay_supervisor.py](../experiments/replay_supervisor.py).
- Exact plotted values: [replay_trace.csv](../data/replay_trace.csv), [replay_results.json](../data/replay_results.json), [timeout_sweep.csv](../data/timeout_sweep.csv).
- Figure inputs, generator/source/export hashes and versions: [figure_manifest.json](../data/figure_manifest.json). Selected command arrays, receipt intervals and matrix values: [figure_data.json](../data/figure_data.json).
- Repeat-render, font/vector, plotted-value and editable-document checks: [figure_validation.json](../data/figure_validation.json).

The topology combines source-supported paths across documented alternatives; it is not a single verified launch configuration. The Raspberry Pi model is deliberately unspecified because repository descriptions differ. Scan bridge variants are labeled as alternatives. The pixel-consuming PD branch is excluded from metric replay. The baseline's direct motor writer is shown separately from the ROS/data path: a deployed gate would have to cover every actuator writer, while this study bypasses motor calls entirely.

B is the source controller, F adds receipt-age gating, and V adds payload usability. The full suite has 960 ticks per policy. T is constrained nonzero motion, including rotation; H is suppressed baseline forward motion when the constructed scene is clear and the latest target payload is valid. Malformed-target ticks are therefore excluded from H by definition. These counts are not physical failure rates. The fault trace shows requested linear commands, and the timeout plot shows sampled command persistence, not braking time. Receipt age cannot establish capture age, and numeric validity cannot establish correct units or observation truth. Research results, runtime code and input data were not changed by this figure revision.

## Architecture preview

![SoccerBot technical topology](architecture.png)

## Fault traces

![Silence versus fresh unusable scan payloads](fault_trace.png)

## Timeout tradeoff

![Constructed timeout sensitivity](timeout_tradeoff.png)

## Optional full scenario audit

![All 12 constructed scenarios](scenario_matrix.png)
