# Autonomous Soccer Robot System (Distributed Edge Architecture)

## Overview
This repository contains the software stack and documentation for a vision-based autonomous soccer robot. The system employs a **Distributed ROS 2 Architecture** designed specifically for low-resource edge devices (like the Raspberry Pi 3B). 

Instead of processing heavy computer vision on the robot, the system splits computing across a network:
1. **The Edge Node (Raspberry Pi 3B)**: Acts as a lightweight data gatherer and actuator. It broadcasts physical camera and YDLidar data over Wi-Fi, and listens for motor speed commands.
2. **The Cloud/Brain Node (Base Station Laptop)**: Subscribes to the robot's sensor data over Wi-Fi, processes the heavy OpenCV ball tracking and obstacle avoidance, and publishes velocity commands back to the robot.

This offloads intensive processing to a high-performance machine while maintaining real-time robotics control via ROS 2.

## System Architecture (Base Station)

The laptop's software is divided into the following primary subsystems:

1. **Camera Vision (`src/soccer_vision`)**: 
   - Receives `/image_raw` from the Pi over Wi-Fi.
   - Utilizes OpenCV (HSV color-space transformations) to track the soccer ball.
   - Publishes the ball coordinates to `/ball_position`.

2. **Lidar Navigation (`src/soccer_navigation`)**:
   - Receives `/scan` (360-degree point cloud) from the Pi.
   - Computes obstacle proximity. If an object is < 0.4m, it calculates and publishes an escape vector `Twist` to `/obstacle_avoidance/cmd_vel`.

3. **Core Brain (`src/core_brain`)**:
   - The decision-making center that subscribes to both modules and uses a Finite State Machine (SEARCH, CHASE, AVOID).

## System Architecture (Raspberry Pi)
The Raspberry Pi runs a lightweight Docker container with ROS 2, providing:
- `v4l2_camera` node: Publishes Pi camera frames.
- `ydlidar_ros2_driver` node: Publishes Lidar ranges.
- `motor_controller` node: Subscribes to `/cmd_vel` and translates Twist vectors into GPIO PWM signals for the L298N driver.

## Directory Structure
```
soccer_bot/
├── docs/                   # Diagrams, hardware schematics, and paper notes
├── scripts/                # Bash scripts for setting up the Pi (Docker) and Laptop
└── src/                    # Source code modules
    ├── soccer_vision/      # ROS 2 Vision Node
    ├── soccer_navigation/  # ROS 2 Lidar Node
    ├── core_brain/         # State machine
    └── motor_control/      # Hardware PWM interfacing
```
